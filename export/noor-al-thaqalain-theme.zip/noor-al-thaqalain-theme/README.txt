WordPress theme: noor-al-thaqalain
=============================

Install: zip the noor-al-thaqalain folder (or use noor-al-thaqalain-theme.zip) and
upload it from Appearance → Themes → Add New → Upload Theme, then activate.

The theme renders the pre-built React app from ./assets. No Node.js, npm or
external service is required on the host. Routes use hash URLs (/#/quran) so the
site works without any rewrite configuration.

Fonts, the hero video and the reference photograph live in ./assets and are
referenced relative to the theme directory, so the install works at the domain
root as well as in a subdirectory where WordPress lives.
